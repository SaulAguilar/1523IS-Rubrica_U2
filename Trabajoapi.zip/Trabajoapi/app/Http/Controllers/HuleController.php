<?php

namespace App\Http\Controllers;

use App\Models\Hule;
use Illuminate\Http\Request;

class HuleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Hule::all();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombres' => 'required',
            'apellidos' => 'required',
            'edad' => 'required',
            'area' => 'required'
        ]);
        $empleado = new Hule;
        $empleado->nombres = $request->nombres;
        $empleado->apellidos = $request->apellidos;
        $empleado->edad = $request->edad;
        $empleado->area = $request->area;
        $empleado->save();
        return $empleado;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Hule  $hule
     * @return \Illuminate\Http\Response
     */
    public function show(Hule $hule)
    {
        return $hule;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Hule  $hule
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hule $hule)
    {
        $request->validate([
            'nombres' => 'required',
            'apellidos' => 'required',
            'edad' => 'required',
            'area' => 'required'
        ]);
        $hule->nombres = $request->nombres;
        $hule->apellidos = $request->apellidos;
        $hule->edad = $request->edad;
        $hule->area = $request->area;
        $hule->update();
        return $hule;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Hule  $hule
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hule = Hule::find($id);

        if(is_null($hule))
        {
            return response()->json('NO SE PUDO REALIZAR CORRECTAMENTE LA OPERACION',404);
        }

        $hule->delete();
        return response()->noContent();
    }
}
